##' Function to remove prior imputation.
##'
##' @param data The data.table object containing the values.
##' @param value The value of the observation.
##' @param flag The flag of the observation.
##' @param processingParameters A list of the parameters for the production
##' processing algorithms.  See defaultProductionParameters() for a starting
##' point.
##' 
##' @return No value is returned.  However, the object "data" which was passed
##' to this function is modified.
##'
##' @examples data = copy(okrapd[areaName=="Sudan",])
##' data[,.(yieldValue, yieldFlag)]
##' removeImputation(data = data, value = "yieldValue", flag = "yieldFlag",
##'     imputedFlag = "T", naFlag = "M")
##' data[,.(yieldValue, yieldFlag)]
##'
##' @export

removeImputation = function(data, value, flag, processingParameters){
    
    ### Data Quality Checks
    if(!exists("ensuredProductionData") || !ensuredProductionData)
        ensureProductionInputs(data = data,
                               processingParameters = processingParameters)
    stopifnot(c(value, flag) %in% colnames(data))
    
    imputedIndex = which(data[[flag]] %in% processingParameters$imputedFlag)
    invisible(data[imputedIndex, `:=`(c(value, flag),
                                      list(NA, processingParameters$naFlag))])
}
